package net.mwangotronix.departmentservice.service;

import net.mwangotronix.departmentservice.payload.DepartmentDto;

public interface DepartmentService {

    DepartmentDto saveDepartment(DepartmentDto departmentDto);

    DepartmentDto getDepartmentByCode(String code);
}
