package net.mwangotronix.departmentservice.controller;


import lombok.RequiredArgsConstructor;
import net.mwangotronix.departmentservice.payload.DepartmentDto;
import net.mwangotronix.departmentservice.service.DepartmentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/departments")
@RequiredArgsConstructor
public class DepartmentController {
    private final DepartmentService departmentService;

    //Save departmentRSTAPI

    @PostMapping("/save")
    public ResponseEntity<DepartmentDto> saveDepartment(@RequestBody DepartmentDto departmentDto) {
        return ResponseEntity.ok(departmentService.saveDepartment(departmentDto));
    }

    @GetMapping("/{code}")
    public ResponseEntity<DepartmentDto> getDepartmentByCode(@PathVariable("code") String code) {
        return ResponseEntity.ok(departmentService.getDepartmentByCode(code));
    }
}
