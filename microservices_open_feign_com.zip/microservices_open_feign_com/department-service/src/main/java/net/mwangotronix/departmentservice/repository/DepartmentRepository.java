package net.mwangotronix.departmentservice.repository;

import net.mwangotronix.departmentservice.modal.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    Department findByDepartmentCode(String code);
}
