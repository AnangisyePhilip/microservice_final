package net.mwangotronix.departmentservice.serviceImpl;

import lombok.RequiredArgsConstructor;
import net.mwangotronix.departmentservice.modal.Department;
import net.mwangotronix.departmentservice.payload.DepartmentDto;
import net.mwangotronix.departmentservice.repository.DepartmentRepository;
import net.mwangotronix.departmentservice.service.DepartmentService;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepository departmentRepository;

    private static DepartmentDto getDepartmentResponseDto(Department department) {
        DepartmentDto responseDto = new DepartmentDto();
        responseDto.setId(department.getId());
        responseDto.setDepartmentName(department.getDepartmentName());
        responseDto.setDepartmentCode(department.getDepartmentCode());
        responseDto.setDepartmentDescription(department.getDepartmentDescription());
        return responseDto;
    }

    @Override
    public DepartmentDto saveDepartment(DepartmentDto departmentDto) {

        //Convert department dto to department jpa entity
        Department department = new Department(
                departmentDto.getId(),
                departmentDto.getDepartmentName(),
                departmentDto.getDepartmentDescription(),
                departmentDto.getDepartmentCode()
        );
        Department savedDepartment = departmentRepository.save(department);

        return getDepartmentResponseDto(savedDepartment);
    }

    @Override
    public DepartmentDto getDepartmentByCode(String code) {

        Department retrievedDepartment=departmentRepository.findByDepartmentCode(code);

        if (retrievedDepartment == null) {
            throw new RuntimeException("Department not found");
        }

        return getDepartmentResponseDto(retrievedDepartment);
    }




}
