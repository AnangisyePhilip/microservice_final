package net.mwangotronix.employeeservice.repository;

import net.mwangotronix.employeeservice.modal.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
