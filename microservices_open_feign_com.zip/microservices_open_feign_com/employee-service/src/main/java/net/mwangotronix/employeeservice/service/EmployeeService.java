package net.mwangotronix.employeeservice.service;

import net.mwangotronix.employeeservice.payload.APIResponseDto;
import net.mwangotronix.employeeservice.payload.EmployeeDto;

public interface EmployeeService {
    EmployeeDto saveEmployee(EmployeeDto employeeDto);

    APIResponseDto getEmployeeById(Long id);

}
