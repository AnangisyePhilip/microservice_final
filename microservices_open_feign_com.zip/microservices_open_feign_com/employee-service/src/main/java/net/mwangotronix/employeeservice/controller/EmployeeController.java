package net.mwangotronix.employeeservice.controller;

import lombok.RequiredArgsConstructor;
import net.mwangotronix.employeeservice.payload.APIResponseDto;
import net.mwangotronix.employeeservice.payload.EmployeeDto;
import net.mwangotronix.employeeservice.service.EmployeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/employees")
public class EmployeeController {
    private final EmployeeService employeeService;


    @PostMapping("/add")
    public ResponseEntity<EmployeeDto> saveEmployee(@RequestBody EmployeeDto employeeDto) {
        return  ResponseEntity.ok(employeeService.saveEmployee(employeeDto));
    }

    @GetMapping("/{id}")
    public  ResponseEntity<APIResponseDto> getEmployeeById(@PathVariable("id") Long id){
        return  ResponseEntity.ok(employeeService.getEmployeeById(id));
    }
}
