package net.mwangotronix.employeeservice.serviceImpl;

import lombok.RequiredArgsConstructor;
import net.mwangotronix.employeeservice.modal.Employee;
import net.mwangotronix.employeeservice.payload.APIResponseDto;
import net.mwangotronix.employeeservice.payload.DepartmentDto;
import net.mwangotronix.employeeservice.payload.EmployeeDto;
import net.mwangotronix.employeeservice.repository.EmployeeRepository;
import net.mwangotronix.employeeservice.service.APIClient;
import net.mwangotronix.employeeservice.service.EmployeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl  implements EmployeeService {

    private final EmployeeRepository employeeRepository;

//    private final RestTemplate restTemplate;

//    private final WebClient webClient;

    private final APIClient apiClient;

    private static EmployeeDto getEmployeeResponseDto(Employee employee) {
        EmployeeDto employeeDto = new EmployeeDto();
        employeeDto.setId(employee.getId());
        employeeDto.setFirstName(employee.getFirstName());
        employeeDto.setLastName(employee.getLastName());
        employeeDto.setEmail(employee.getEmail());
        employeeDto.setDepartmentCode(employee.getDepartmentCode());
        return employeeDto;
    }

    @Override
    public EmployeeDto saveEmployee(EmployeeDto employeeDto) {

        Employee employee = new Employee();
        employee.setFirstName(employeeDto.getFirstName());
        employee.setLastName(employeeDto.getLastName());
        employee.setEmail(employeeDto.getEmail());
        employee.setDepartmentCode(employeeDto.getDepartmentCode());

        Employee savedEmployee = employeeRepository.save(employee);

        return getEmployeeResponseDto(savedEmployee);
    }

    @Override
    public APIResponseDto getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id).get();
//       ResponseEntity<DepartmentDto> responseEntity= restTemplate.getForEntity("http://localhost:8032/api/departments/" + employee.getDepartmentCode(), DepartmentDto.class);
//
//       DepartmentDto departmentDto = responseEntity.getBody();


//       DepartmentDto departmentDto=  webClient.get()
//                .uri("http://localhost:8032/api/departments/" + employee.getDepartmentCode())
//                .retrieve()
//                .bodyToMono(DepartmentDto.class)
//                .block();

       DepartmentDto departmentDto= apiClient.getDepartmentByCode(employee.getDepartmentCode());


        EmployeeDto employeeDto = getEmployeeResponseDto(employee);

       APIResponseDto apiResponseDto = new APIResponseDto();

       apiResponseDto.setEmployee(employeeDto);
       apiResponseDto.setDepartment(departmentDto);

        return apiResponseDto;
    }

}
