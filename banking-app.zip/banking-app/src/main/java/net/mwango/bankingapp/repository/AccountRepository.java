package net.mwango.bankingapp.repository;

import net.mwango.bankingapp.modal.Account;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Account, Long> {
}
