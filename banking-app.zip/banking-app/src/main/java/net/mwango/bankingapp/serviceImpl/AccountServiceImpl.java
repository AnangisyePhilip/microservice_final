package net.mwango.bankingapp.serviceImpl;

import lombok.RequiredArgsConstructor;
import net.mwango.bankingapp.mapper.AccountMapper;
import net.mwango.bankingapp.modal.Account;
import net.mwango.bankingapp.payload.AccountDto;
import net.mwango.bankingapp.repository.AccountRepository;
import net.mwango.bankingapp.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    @Override
    public AccountDto createAccount(AccountDto accountDto) {
        Account account= AccountMapper.mapToAccount(accountDto);
        Account savedAccount=accountRepository.save(account);
        return AccountMapper.mapToAccountDto(savedAccount);
    }

    @Override
    public AccountDto getAccountById(Long id) {
      Account account=accountRepository.findById(id).orElseThrow(()->new RuntimeException("Account not found"));
        return AccountMapper.mapToAccountDto(account);
    }

    @Override
    public AccountDto deposit(Long id, double amount) {
        Account account=accountRepository.findById(id).orElseThrow(()->new RuntimeException("Account not found"));
        double newBalance=account.getBalance()+amount;
        account.setBalance(newBalance);
        Account savedAccount=accountRepository.save(account);

        return AccountMapper.mapToAccountDto(savedAccount);
    }

    @Override
    public AccountDto withdraw(Long id, double amount) {
        Account account=accountRepository.findById(id).orElseThrow(()->new RuntimeException("Account not found"));

        if(account.getBalance()-amount<0){
            throw new RuntimeException("Insufficient funds");
        }
        double newBalance=account.getBalance()-amount;
        account.setBalance(newBalance);
        Account savedAccount=accountRepository.save(account);

        return AccountMapper.mapToAccountDto(savedAccount);
    }

    @Override
    public List<AccountDto> getAllAccounts() {

        List<Account> accounts=accountRepository.findAll();
       return accounts.stream().map(AccountMapper::mapToAccountDto).collect(Collectors.toList());
    }

    @Override
    public void deleteAccountById(Long id) {
        Account account=accountRepository.findById(id).orElseThrow(()->new RuntimeException("Account not found"));
        accountRepository.delete(account);
    }


}
