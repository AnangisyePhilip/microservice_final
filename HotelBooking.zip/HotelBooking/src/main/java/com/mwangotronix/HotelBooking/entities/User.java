package com.mwangotronix.HotelBooking.entities;

import com.mwangotronix.HotelBooking.enums.UserRole;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "users")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Email is required")
    private String email;

    private String firstName;
    private String lastName;

    @NotBlank(message = "Password is required")
    private String password;
    private String phoneNumber;

    @Enumerated(EnumType.STRING)
    private UserRole role;
    private boolean active;
    private final LocalDate createdAt=LocalDate.now();


}
