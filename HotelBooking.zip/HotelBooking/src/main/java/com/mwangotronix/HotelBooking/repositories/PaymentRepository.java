package com.mwangotronix.HotelBooking.repositories;

import com.mwangotronix.HotelBooking.entities.PaymentEntity;
import com.stripe.model.giftcards.Card;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<PaymentEntity, Long> {

}
