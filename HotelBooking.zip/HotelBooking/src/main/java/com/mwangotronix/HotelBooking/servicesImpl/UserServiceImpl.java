package com.mwangotronix.HotelBooking.servicesImpl;

import com.mwangotronix.HotelBooking.dtos.*;
import com.mwangotronix.HotelBooking.entities.Booking;
import com.mwangotronix.HotelBooking.entities.User;
import com.mwangotronix.HotelBooking.enums.UserRole;
import com.mwangotronix.HotelBooking.exceptions.InvalidCredentialException;
import com.mwangotronix.HotelBooking.exceptions.NotFoundException;
import com.mwangotronix.HotelBooking.repositories.BookingRepository;
import com.mwangotronix.HotelBooking.repositories.UserRepository;
import com.mwangotronix.HotelBooking.security.JwtUtils;
import com.mwangotronix.HotelBooking.services.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    private final ModelMapper modelMapper;
    private final BookingRepository bookingRepository;

    
    @Override
    public Response registerUser(RegistrationRequest registrationRequest) {
        log.info("INSIDE registerUser()");
    UserRole role= UserRole.CUSTOMER;

    if(registrationRequest.getRole() != null){
        role = registrationRequest.getRole();
    }

    User userToSave=User.builder()
            .firstName(registrationRequest.getFirstName())
            .lastName(registrationRequest.getLastName())
            .email(registrationRequest.getEmail())
            .password(passwordEncoder.encode(registrationRequest.getPassword()))
            .phoneNumber(registrationRequest.getPhoneNumber())
            .role(role)
            .active(true)
            .build();

    userRepository.save(userToSave);

        return Response.builder()
                .status(200)
                .message("User Registered Successfully")
                .build();
    }

    @Override
    public Response loginUser(LoginRequest loginRequest) {
        log.info("Login attempt for email: {}", loginRequest.getEmail());

        // Input validation
        if (loginRequest.getEmail() == null || loginRequest.getPassword() == null) {
            throw new InvalidCredentialException("Email and password are required");
        }

        User user = userRepository.findByEmail(loginRequest.getEmail())
                .orElseThrow(() -> new InvalidCredentialException("Invalid credentials")); // Don't reveal email exists

        // Check if user is active before password verification
        if (!user.isActive()) {
            throw new InvalidCredentialException("Account is disabled");
        }

        if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPassword())) {
            // Consider adding rate limiting/account lockout here
            log.warn("Failed login attempt for email: {}", loginRequest.getEmail());
            throw new InvalidCredentialException("Invalid credentials"); // Same message as email not found
        }

        String token = jwtUtils.generateToken(user.getEmail());
        log.info("User logged in successfully: {}", user.getEmail());

        return Response.builder()
                .status(200)
                .message("Login successful")
                .role(user.getRole())
                .token(token)
                .active(user.isActive())
                .expirationTime("6 months") // More descriptive
                .build();
    }

    @Override
    public Response getAllUsers() {
        log.info("INSIDE getAllUsers()");
        List<User> users=userRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));

        List<UserDto> userDtoList=modelMapper.map(users,new TypeToken<List<UserDto>>(){}.getType());

        return Response.builder()
                .status(200)
                .message("success")
                .users(userDtoList)
                .build();
    }


    @Override
    public Response getOwnAccountDetails() {
        log.info("INSIDE getOwnAccount()");
        String email= SecurityContextHolder.getContext().getAuthentication().getName();
        User user=userRepository.findByEmail(email).orElseThrow(() -> new NotFoundException("Email Not Found"));

        UserDto userDto=modelMapper.map(user,UserDto.class);

        return Response.builder()
                .status(200)
                .message("success")
                .user(userDto)
                .build();
    }

    @Override
    public User getCurrentLoggedInUser() {
        log.info("INSIDE getCurrentLoggedInUser()");
        String email= SecurityContextHolder.getContext().getAuthentication().getName();

        return userRepository.findByEmail(email).orElseThrow(() -> new NotFoundException("Email Not Found"));
    }

    @Override
    public Response updateOwnAccount(UserDto userDto) {
        log.info("INSIDE updateOwnAccount()");
        User existingUser=getCurrentLoggedInUser();

        if(userDto.getEmail() != null){existingUser.setEmail(userDto.getEmail());}
        if (userDto.getFirstName() != null){existingUser.setFirstName(userDto.getFirstName());}
        if (userDto.getLastName() != null){existingUser.setLastName(userDto.getLastName());}
        if (userDto.getPhoneNumber() != null){existingUser.setPhoneNumber(userDto.getPhoneNumber());}

        if(userDto.getPassword() != null){
            existingUser.setPassword(passwordEncoder.encode(userDto.getPassword()));}

        userRepository.save(existingUser);
        return Response.builder()
                .status(200)
                .message("User updated Successfully")
                .build();
    }

    @Override
    public Response deleteOwnAccount(UserDto userDto) {
        log.info("INSIDE deleteOwnAccount()");
        User existingUser=getCurrentLoggedInUser();

        userRepository.delete(existingUser);

        return Response.builder()
                .status(200)
                .message("User deleted Successfully")
                .build();
    }

    @Override
    public Response getMyBookingHistory() {
        log.info("INSIDE getMyBookingHistory()");
        User currentUser=getCurrentLoggedInUser();

        List<Booking> bookingList=bookingRepository.findByUserId(currentUser.getId());

        List<BookingDto> bookingDtoList=modelMapper.map(bookingList, new TypeToken<List<BookingDto>>(){}.getType());

        return Response.builder()
                .status(200)
                .message("success")
                .bookings(bookingDtoList)
                .build();
    }
}
