package com.mwangotronix.HotelBooking.entities;

import com.mwangotronix.HotelBooking.enums.RoomType;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "rooms")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Min(value = 1,message = "Room number must be at least 1")
    @Column(unique = true)
    private Integer roomNumber;

    @Enumerated(EnumType.STRING)
    private RoomType type;

    @DecimalMin(value="10000.0",message = "Price per night is required")
    private BigDecimal pricePerNight;

    @Min(value = 1,message = "Capacity must be at least 1")
    private Integer capacity;

    private String description;

    private String imageUrl;
}
