package com.mwangotronix.HotelBooking.services;

import com.mwangotronix.HotelBooking.dtos.BookingDto;
import com.mwangotronix.HotelBooking.dtos.Response;
import com.mwangotronix.HotelBooking.entities.Booking;

public interface BookingService {
    Response getAllBookings();
    Response createBooking(BookingDto bookingDto);
    Response findBookingByBookingReferenceNo(String bookingReferenceNo);
    Response updateBooking(BookingDto bookingDto);
}
