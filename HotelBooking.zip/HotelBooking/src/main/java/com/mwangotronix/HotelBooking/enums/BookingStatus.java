package com.mwangotronix.HotelBooking.enums;

public enum BookingStatus {
    BOOKED,
    CHECKED_OUT,
    CHECKED_IN,
    CANCELLED,
}
