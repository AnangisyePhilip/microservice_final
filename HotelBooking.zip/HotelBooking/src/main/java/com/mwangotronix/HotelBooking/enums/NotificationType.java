package com.mwangotronix.HotelBooking.enums;

public enum NotificationType {
    EMAIL,
    SMS,
    WHATSAPP,
}
