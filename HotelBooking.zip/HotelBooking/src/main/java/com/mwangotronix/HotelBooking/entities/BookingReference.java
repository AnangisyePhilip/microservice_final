package com.mwangotronix.HotelBooking.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
//@Table(name = "booking_refernces")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BookingReference {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String referenceNo;

}
