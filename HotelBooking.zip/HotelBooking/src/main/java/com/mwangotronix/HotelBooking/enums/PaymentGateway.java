package com.mwangotronix.HotelBooking.enums;

public enum PaymentGateway {
    PAYPAL,
    STRIPE,
    PAYSTACK
}
