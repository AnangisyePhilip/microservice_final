package com.mwangotronix.HotelBooking.repositories;

import com.mwangotronix.HotelBooking.entities.Room;
import com.mwangotronix.HotelBooking.enums.RoomType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface RoomRepository extends JpaRepository<Room, Long> {

    @Query(value = """
SELECT * FROM room r
WHERE r.id NOT IN (
    SELECT DISTINCT b.room_id FROM bookings b
    WHERE b.check_out_date > :checkInDate
    AND b.check_in_date < :checkOutDate
    AND b.booking_status IN ('BOOKED', 'CHECKED_OUT')
)
AND (:roomType IS NULL OR r.type = :roomType)
""", nativeQuery = true)
    List<Room>  findAvailableRooms(
            @Param("checkInDate") LocalDate checkInDate,
            @Param("checkOutDate") LocalDate checkOutDate,
            @Param("roomType") String roomType  // Note: Changed to String for native query
    );


    @Query(value = """
SELECT * FROM room r
WHERE CAST(r.room_number AS VARCHAR) LIKE CONCAT('%', :searchParam, '%')
    OR LOWER(r.type) LIKE LOWER(CONCAT('%', :searchParam, '%'))
    OR CAST(r.price_per_night AS VARCHAR) LIKE CONCAT('%', :searchParam, '%')
    OR CAST(r.capacity AS VARCHAR) LIKE CONCAT('%', :searchParam, '%')
    OR LOWER(r.description) LIKE LOWER(CONCAT('%', :searchParam, '%'))
""", nativeQuery = true)
    List<Room> searchRooms(@Param("searchParam") String searchParam);

}
