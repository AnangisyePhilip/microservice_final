package com.mwangotronix.HotelBooking.repositories;

import com.mwangotronix.HotelBooking.entities.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUserId(Long userId);

    Optional<Booking> findByBookingReference(String bookingReference);

    @Query(value = """
SELECT CASE WHEN COUNT(b.id) = 0 THEN true ELSE false END 
FROM bookings b
WHERE b.room_id = :roomId
    AND :checkInDate <= b.check_out_date
    AND :checkOutDate >= b.check_in_date 
    AND b.booking_status IN ('BOOKED', 'CHECKED_IN')
""", nativeQuery = true)
    boolean isRoomAvailable(@Param("roomId") Long roomId,
                            @Param("checkInDate") LocalDate checkInDate,
                            @Param("checkOutDate") LocalDate checkOutDate);

}
