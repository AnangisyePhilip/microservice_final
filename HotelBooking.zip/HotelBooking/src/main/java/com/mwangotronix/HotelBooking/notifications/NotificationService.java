package com.mwangotronix.HotelBooking.notifications;

import com.mwangotronix.HotelBooking.dtos.NotificationDto;

public interface NotificationService {
    void sendEmail(NotificationDto notificationDto);

    void sendSms(NotificationDto notificationDto);

    void sendWhatsapp(NotificationDto notificationDto);
}
