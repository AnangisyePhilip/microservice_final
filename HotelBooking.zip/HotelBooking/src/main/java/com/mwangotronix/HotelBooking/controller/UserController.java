package com.mwangotronix.HotelBooking.controller;

import com.mwangotronix.HotelBooking.dtos.Response;
import com.mwangotronix.HotelBooking.dtos.UserDto;
import com.mwangotronix.HotelBooking.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/user")
public class UserController {

    private final UserService userService;

    @GetMapping("/all")
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<Response> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @PutMapping("/update")
    public ResponseEntity<Response> updateOwnAccount(@RequestBody UserDto userDto) {
        return ResponseEntity.ok(userService.updateOwnAccount(userDto));
    }


    @DeleteMapping("/delete")
    public ResponseEntity<Response> deleteOwnAccount(@RequestBody UserDto userDto) {
        return ResponseEntity.ok(userService.deleteOwnAccount(userDto));
    }

    @GetMapping("/account")
    public ResponseEntity<Response> getOwnAccount() {
        return ResponseEntity.ok(userService.getOwnAccountDetails());
    }


    @GetMapping("/bookings")
    public ResponseEntity<Response> getMyBookings() {
        return ResponseEntity.ok(userService.getMyBookingHistory());
    }

}
