package com.mwangotronix.HotelBooking.servicesImpl;

import com.mwangotronix.HotelBooking.dtos.Response;
import com.mwangotronix.HotelBooking.dtos.RoomDto;
import com.mwangotronix.HotelBooking.entities.Room;
import com.mwangotronix.HotelBooking.enums.RoomType;
import com.mwangotronix.HotelBooking.exceptions.InvalidBookingStateAndaDateException;
import com.mwangotronix.HotelBooking.exceptions.NotFoundException;
import com.mwangotronix.HotelBooking.repositories.RoomRepository;
import com.mwangotronix.HotelBooking.services.RoomService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;
    private final ModelMapper modelMapper;

    private final static String IMAGE_DIRECTORY = System.getProperty("user.dir") + "/images";
//    private final static String IMAGE_DIRECTORY = System.getProperty("user.dir") + "/home/philip/BACKEND_PRO/projects_2025/HotelBooking/images/";
    private final HttpMessageConverters messageConverters;


    @Override
    public Response addRoom(RoomDto roomDto, MultipartFile imageFile) {
        Room roomToSave= modelMapper.map(roomDto, Room.class);
        if(imageFile !=null){
            String imagePath=saveImage(imageFile);
            roomToSave.setImageUrl(imagePath);
        }

        roomRepository.save(roomToSave);
        return Response.builder()
                .status(200)
                .message("Room Successfully Added")
                .build();
    }


    @Override
    public Response updateRoom(RoomDto roomDto, MultipartFile imageFile) {
        Room existingRoom = roomRepository.findById(roomDto.getId()).orElseThrow(() -> new NotFoundException("Room not found"));

        if(imageFile != null && !imageFile.isEmpty()) {
            String imagePath=saveImage(imageFile);
            existingRoom .setImageUrl(imagePath);
        }

        if (roomDto.getRoomNumber() != null && roomDto.getRoomNumber() >=0) {
            existingRoom.setRoomNumber(roomDto.getRoomNumber());
        }

        if(roomDto.getPricePerNight() !=null && roomDto.getPricePerNight().compareTo(BigDecimal.ZERO)>=0){
            existingRoom.setPricePerNight(roomDto.getPricePerNight());
        }

        if(roomDto.getCapacity() !=null && roomDto.getCapacity()>=0){
            existingRoom.setCapacity(roomDto.getCapacity());
        }

        if (roomDto.getType() != null) {
            existingRoom.setType(roomDto.getType());
        }

        if (roomDto.getDescription() != null) {
            existingRoom.setDescription(roomDto.getDescription());
        }

        roomRepository.save(existingRoom);

        return Response.builder()
                .status(200)
                .message("Room Updated Successfull")
                .build();
    }

    @Override
    public Response getAllRooms() {
        List<Room> rooms = roomRepository.findAll(Sort.by(Sort.Direction.DESC,"id"));
        List<RoomDto> roomDtoList=modelMapper.map(rooms,new TypeToken<List<RoomDto>>(){}.getType());

        return Response.builder()
                .status(200)
                .message("Success")
                .rooms(roomDtoList)
                .build();
    }

    @Override
    public Response getRoomById(Long id) {
        Room existingRoom = roomRepository.findById(id).orElseThrow(() -> new NotFoundException("Room not found"));

        RoomDto roomDto = modelMapper.map(existingRoom, RoomDto.class);
        return Response.builder()
                .status(200)
                .message("Success")
                .room(roomDto)
                .build();
    }

    @Override
    public Response deleteRoom(Long id) {

        if(!roomRepository.existsById(id)){
            throw new NotFoundException("Room not found");
        }
        roomRepository.deleteById(id);

        return Response.builder()
                .status(200)
                .message("Room deleted Successfully")
                .build();
    }

    @Override
    public Response getAvailableRooms(LocalDate checkInDate, LocalDate checkOutDate, RoomType roomType) {

        // VALIDATION: ENSURE Check in date is not before today
        if (checkInDate.isBefore(LocalDate.now())) {
            throw new InvalidBookingStateAndaDateException("Check in date must not be before today ");
        }

        // VALIDATION: ENSURE Check in date is not before check in date
        if (checkOutDate.isBefore(checkInDate)) {
            throw new InvalidBookingStateAndaDateException("Check in date must be before checkin date  ");
        }

        // VALIDATION: ENSURE Check in date is not the same as Checkout date
        if (checkInDate.isEqual(checkOutDate)) {
            throw new InvalidBookingStateAndaDateException("Check in date must be before today ");
        }

        String roomTypeValue=roomType.toString();

        List<Room> roomList=roomRepository.findAvailableRooms(checkInDate,checkOutDate,roomTypeValue);

        List<RoomDto> roomDtoList=modelMapper.map(roomList, new TypeToken<List<RoomDto>>(){}.getType());

        return Response.builder()
                .status(200)
                .message("success")
                .rooms(roomDtoList)
                .build();
    }


    @Override
    public List<RoomType> getAllRoomTypes() {
        return Arrays.asList(RoomType.values());
    }

    @Override
    public Response searchRoom(String input) {
        List<Room> roomList=roomRepository.searchRooms(input);

        List<RoomDto> roomDtoList=modelMapper.map(roomList, new TypeToken<List<RoomDto>>(){}.getType());

        return Response.builder()
                .status(200)
                .message("success")
                .rooms(roomDtoList)
                .build();
    }

    // Save image
    private String saveImage(MultipartFile imageFile) {
        if(!imageFile.getContentType().startsWith("image/")) {
            throw new RuntimeException("Invalid image type");
        }

        // Create directory if it doesnt exists
        File directory = new File(IMAGE_DIRECTORY);
        if(!directory.exists()) {
            directory.mkdir();
        }

        //Generate unique file name
        String uniqueFileName= UUID.randomUUID() + " " + imageFile.getOriginalFilename();
        String imagePath= IMAGE_DIRECTORY + uniqueFileName;

        try{
        File destinationFile = new File(imagePath);
        imageFile.transferTo(destinationFile);
        } catch (Exception ex){
            throw new IllegalArgumentException(ex.getMessage());
        }
    return imagePath;
    }
}
