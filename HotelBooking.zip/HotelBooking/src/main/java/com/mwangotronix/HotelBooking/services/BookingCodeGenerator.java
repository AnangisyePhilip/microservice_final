package com.mwangotronix.HotelBooking.services;


import com.mwangotronix.HotelBooking.entities.BookingReference;
import com.mwangotronix.HotelBooking.repositories.BookingReferenceRepository;
import com.mwangotronix.HotelBooking.repositories.BookingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
@RequiredArgsConstructor
public class BookingCodeGenerator {

    private final BookingReferenceRepository bookingReferenceRepository;

    public String generateBookingReference(){
        String bookingReference;
        do {
        bookingReference=generateRandomAlphanumericCode(10); // generate a unique code of length 10
        } while (isBookingReferenceExists(bookingReference));
        saveBookingReference(bookingReference);
        return bookingReference;
    }

    private String generateRandomAlphanumericCode(int length){
        String character="ABCDEFGHIJKLMNOPQRSUVWXWZ123456789";

        Random random = new Random();

        StringBuilder stringBuilder = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(character.length());
            stringBuilder.append(character.charAt(index));
        }
        return stringBuilder.toString();
    }

    private boolean isBookingReferenceExists(String bookingReference){
        return bookingReferenceRepository.findByReferenceNo(bookingReference).isPresent();
    }

    private void saveBookingReference(String bookingReference){
        BookingReference bookingReferenceToSave = new BookingReference()
                .builder()
                .referenceNo(bookingReference)
                .build();
        bookingReferenceRepository.save(bookingReferenceToSave);
    }


}
