package com.mwangotronix.HotelBooking.services;

import com.mwangotronix.HotelBooking.dtos.Response;
import com.mwangotronix.HotelBooking.dtos.RoomDto;
import com.mwangotronix.HotelBooking.enums.RoomType;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

public interface RoomService {
    Response addRoom(RoomDto roomDto, MultipartFile importFile);

    Response updateRoom(RoomDto roomDto, MultipartFile importFile);

    Response getAllRooms();

    Response getRoomById(Long id);

    Response deleteRoom(Long id);

    Response getAvailableRooms(LocalDate checkInDate, LocalDate checkOutDate, RoomType roomType);

    List<RoomType> getAllRoomTypes();

    Response searchRoom(String input);

}
