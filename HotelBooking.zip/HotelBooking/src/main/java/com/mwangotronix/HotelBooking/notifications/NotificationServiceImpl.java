package com.mwangotronix.HotelBooking.notifications;

import com.mwangotronix.HotelBooking.dtos.NotificationDto;
import com.mwangotronix.HotelBooking.entities.Notification;
import com.mwangotronix.HotelBooking.enums.NotificationType;
import com.mwangotronix.HotelBooking.repositories.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService {

    
    private final JavaMailSender javaMailSender;

    private final NotificationRepository notificationRepository;

    @Override
    @Async
    public void sendEmail(NotificationDto notificationDto) {
        log.info("Sending Email......");
        SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
        simpleMailMessage.setTo(notificationDto.getRecipient());
        simpleMailMessage.setSubject(notificationDto.getSubject());
        simpleMailMessage.setText(notificationDto.getBody());

        javaMailSender.send(simpleMailMessage);  // Send email

        // Save to database
        Notification notification=Notification.builder()
                .recipient(notificationDto.getRecipient())
                .subject(notificationDto.getSubject())
                .body(notificationDto.getBody())
                .bookingReference(notificationDto.getBookingReference())
                .type(NotificationType.EMAIL)
                .build();

        notificationRepository.save(notification);
    }

    @Override
    public void sendSms(NotificationDto notificationDto) {

    }

    @Override
    public void sendWhatsapp(NotificationDto notificationDto) {

    }
}
