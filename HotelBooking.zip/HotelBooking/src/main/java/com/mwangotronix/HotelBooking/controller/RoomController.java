package com.mwangotronix.HotelBooking.controller;


import com.mwangotronix.HotelBooking.dtos.Response;
import com.mwangotronix.HotelBooking.dtos.RoomDto;
import com.mwangotronix.HotelBooking.enums.RoomType;
import com.mwangotronix.HotelBooking.services.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/rooms")
public class RoomController {
    private final RoomService roomService;

    @PostMapping("/add")
    @PreAuthorize("hasAuthority('ADMIN')") // Admin alone have access to this API
    public ResponseEntity<Response> addRoom(
            @RequestParam Integer roomNumber,
            @RequestParam RoomType roomType,
            @RequestParam BigDecimal pricePerNight,
            @RequestParam Integer capacity,
            @RequestParam String description,
            @RequestParam MultipartFile imageFile
            )
    {
        RoomDto roomDto=RoomDto.builder()
                .roomNumber(roomNumber)
                .type(roomType)
                .pricePerNight(pricePerNight)
                .capacity(capacity)
                .description(description)
                .build();
        return ResponseEntity.ok(roomService.addRoom(roomDto, imageFile));
    }


    @PutMapping("/update")
    @PreAuthorize("hasAnyAuthority('ADMIN')") // Admin alone have access to this API
    public ResponseEntity<Response> updateRoom(
            @RequestParam (value = "roomNumber",required = false) Integer roomNumber,
            @RequestParam (value = "roomType",required = false) RoomType roomType,
            @RequestParam (value = "pricePerNight",required = false) BigDecimal pricePerNight,
            @RequestParam (value = "capacity",required = false) Integer capacity,
            @RequestParam (value = "description",required = false) String description,
            @RequestParam (value = "id",required = false) Long  id,
            @RequestParam (value = "roomNumber",required = false)MultipartFile imageFile
    )
    {
        RoomDto roomDto=RoomDto.builder()
                .roomNumber(roomNumber)
                .type(roomType)
                .pricePerNight(pricePerNight)
                .capacity(capacity)
                .description(description)
                .build();
        return ResponseEntity.ok(roomService.updateRoom(roomDto, imageFile));
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyAuthority('ADMIN')") // Admin alone have access to this API
    public ResponseEntity<Response> getAllRooms() {
        return ResponseEntity.ok(roomService.getAllRooms());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN')") // Admin alone have access to this API
    public ResponseEntity<Response> getRoomById(@PathVariable Long id) {
        return ResponseEntity.ok(roomService.getRoomById(id));
    }

    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN')") // Admin alone have access to this API
    public ResponseEntity<Response> deleteRoomById(@PathVariable Long id) {
        return ResponseEntity.ok(roomService.deleteRoom(id));
    }

    @GetMapping("/available")
    public ResponseEntity<Response> getAvailableRooms(
            @RequestParam LocalDate checkInDate,
            @RequestParam LocalDate checkOutDate,
            @RequestParam (required = false) RoomType roomType
            ) {
        return ResponseEntity.ok(roomService.getAvailableRooms(checkInDate, checkOutDate, roomType));
    }

    @GetMapping("/types")
    public ResponseEntity<Response> getRoomTypes() {
        return ResponseEntity.ok(roomService.getAllRooms());
    }

    @GetMapping("/search")
    public ResponseEntity<Response> searchRoom(@RequestParam String input){
        return ResponseEntity.ok(roomService.searchRoom(input));
    }
    
}
