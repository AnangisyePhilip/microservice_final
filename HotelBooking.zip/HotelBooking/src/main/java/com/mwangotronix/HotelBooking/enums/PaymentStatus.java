package com.mwangotronix.HotelBooking.enums;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED,
    REFUNDED,
    REVERSED
}
