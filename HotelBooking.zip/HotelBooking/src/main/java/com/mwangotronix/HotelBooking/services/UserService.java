package com.mwangotronix.HotelBooking.services;

import com.mwangotronix.HotelBooking.dtos.LoginRequest;
import com.mwangotronix.HotelBooking.dtos.RegistrationRequest;
import com.mwangotronix.HotelBooking.dtos.Response;
import com.mwangotronix.HotelBooking.dtos.UserDto;
import com.mwangotronix.HotelBooking.entities.User;

public interface UserService {
    Response registerUser(RegistrationRequest registrationRequest);

    Response loginUser(LoginRequest loginRequest);

    Response getAllUsers();

    Response getOwnAccountDetails();

    User getCurrentLoggedInUser();

    Response updateOwnAccount(UserDto userDto);

    Response deleteOwnAccount(UserDto userDto);

    Response getMyBookingHistory();

}
