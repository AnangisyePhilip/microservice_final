package com.mwangotronix.HotelBooking.servicesImpl;

import com.mwangotronix.HotelBooking.dtos.BookingDto;
import com.mwangotronix.HotelBooking.dtos.NotificationDto;
import com.mwangotronix.HotelBooking.dtos.Response;
import com.mwangotronix.HotelBooking.entities.Booking;
import com.mwangotronix.HotelBooking.entities.Room;
import com.mwangotronix.HotelBooking.entities.User;
import com.mwangotronix.HotelBooking.enums.BookingStatus;
import com.mwangotronix.HotelBooking.enums.PaymentStatus;
import com.mwangotronix.HotelBooking.exceptions.InvalidBookingStateAndaDateException;
import com.mwangotronix.HotelBooking.exceptions.NotFoundException;
import com.mwangotronix.HotelBooking.notifications.NotificationService;
import com.mwangotronix.HotelBooking.repositories.BookingRepository;
import com.mwangotronix.HotelBooking.repositories.RoomRepository;
import com.mwangotronix.HotelBooking.services.BookingCodeGenerator;
import com.mwangotronix.HotelBooking.services.BookingService;
import com.mwangotronix.HotelBooking.services.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;
    private final NotificationService notificationService;
    private final ModelMapper modelMapper;
    private final UserService userService;
    private final BookingCodeGenerator bookingCodeGenerator;


    @Override
    public Response getAllBookings() {
        List<Booking> bookingList = bookingRepository.findAll();
        List<BookingDto> bookingDtoList=modelMapper.map(bookingList,new TypeToken<List<BookingDto>>(){}.getType());

        for (BookingDto bookingDto : bookingDtoList) {
            bookingDto.setUser(null);
            bookingDto.setRoom(null);
        }

        return Response.builder()
                .status(200)
                .message("success")
                .build();
    }

    @Override
    public Response createBooking(BookingDto bookingDto) {

        User currentUser=userService.getCurrentLoggedInUser();

        Room room=roomRepository.findById(bookingDto.getRoomId())
                .orElseThrow(() -> new NotFoundException("Room not found"));

        // VALIDATION: ENSURE Check in date is not before today
        if (bookingDto.getCheckInDate().isBefore(LocalDate.now())) {
            throw new InvalidBookingStateAndaDateException("Check in date must not be before today ");
        }

        // VALIDATION: ENSURE Check in date is not before check in date
        if (bookingDto.getCheckOutDate().isBefore(bookingDto.getCheckInDate())) {
            throw new InvalidBookingStateAndaDateException("Check in date must be before checkin date  ");
        }

        // VALIDATION: ENSURE Check in date is not the same as Checkout date
        if (bookingDto.getCheckInDate().isEqual(bookingDto.getCheckOutDate())) {
            throw new InvalidBookingStateAndaDateException("Check in date must be before today ");
        }

        // valid room availability
boolean isAvailable=bookingRepository.isRoomAvailable(room.getId(),bookingDto.getCheckInDate(),bookingDto.getCheckOutDate());

        if (!isAvailable) {
            throw new InvalidBookingStateAndaDateException("Room is not available to be booked");
        }

        BigDecimal totalPrice=calculateTotalPrice(room,bookingDto);
        String bookingReference=bookingCodeGenerator.generateBookingReference();

        //create and save to database
        Booking booking=new Booking();
        booking.setUser(currentUser);
        booking.setRoom(room);
        booking.setCheckInDate(bookingDto.getCheckInDate());
        booking.setCheckOutDate(bookingDto.getCheckOutDate());
        booking.setTotalPrice(totalPrice);
        booking.setBookingReference(bookingReference);
        booking.setBookingStatus(BookingStatus.BOOKED);
        booking.setPaymentStatus(PaymentStatus.PENDING);
        booking.setCreatedAt(LocalDate.now());

        bookingRepository.save(booking);

        String paymentLink="http://localhost:/payment/" + bookingReference + "/" + totalPrice;

        //Send Email to user via mail
        NotificationDto notificationDto=NotificationDto.builder()
                .recipient(currentUser.getEmail())
                .subject("BOOKING CONFIRMATION")
                .body(String.format("Your Booking has been created successfully. \n Please proceed with your payment using the payment" +
                        "like below \n%s ",paymentLink))
                .bookingReference(bookingReference)
                .build();

        notificationService.sendEmail(notificationDto);

        return Response.builder()
                .status(200)
                .message("Booking is successful")
                .booking(bookingDto)
                .build();
    }

    @Override
    public Response findBookingByBookingReferenceNo(String bookingReferenceNo) {
        Booking booking=bookingRepository.findByBookingReference(bookingReferenceNo).orElseThrow(() -> new NotFoundException("Booking not found"));

        BookingDto bookingDto=modelMapper.map(booking,BookingDto.class);

        return Response.builder()
                .status(200)
                .message("success")
                .booking(bookingDto)
                .build();
    }

    @Override
    public Response updateBooking(BookingDto bookingDto) {
        if(bookingDto.getId()==null) throw new NotFoundException("Booking not found");

        Booking existingBooking=bookingRepository.findById(bookingDto.getId()).orElseThrow(() -> new NotFoundException("Booking not found"));

        if (bookingDto.getBookingStatus() !=null){
            existingBooking.setBookingStatus(bookingDto.getBookingStatus());
        }

        if (bookingDto.getPaymentStatus() !=null){
            existingBooking.setPaymentStatus(bookingDto.getPaymentStatus());
        }
        bookingRepository.save(existingBooking);
        return Response.builder()
                .status(200)
                .message("Booking Updated Successfully")
                .build();
    }

    private BigDecimal calculateTotalPrice(Room room, BookingDto bookingDto) {
        BigDecimal pricePerNight=room.getPricePerNight();
        long days= ChronoUnit.DAYS.between(bookingDto.getCheckInDate(),bookingDto.getCheckOutDate());
        return pricePerNight.multiply(new BigDecimal(days));
    }

}
