package com.mwangotronix.HotelBooking.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER,
}
