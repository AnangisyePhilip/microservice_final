package com.mwangotronix.HotelBooking.controller;

import com.mwangotronix.HotelBooking.dtos.BookingDto;
import com.mwangotronix.HotelBooking.dtos.Response;
import com.mwangotronix.HotelBooking.services.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {
    private final BookingService bookingService;

    @GetMapping("/all")
    @PreAuthorize("hasAuthority('ADMIN')")  // ADMIN alone have access to this API
    private ResponseEntity<Response> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    @PostMapping("/add")
    @PreAuthorize("hasAuthority('ADMIN') or hasAuthority('CUSTOMER')")  // ADMIN and customer alone have access to this API
    private ResponseEntity<Response> createBooking(@RequestBody BookingDto bookingDto){
        return ResponseEntity.ok(bookingService.createBooking(bookingDto));
    }

    @GetMapping("/booking/{bookingReferenceNo}")
    @PreAuthorize("hasAuthority('ADMIN')")  // ADMIN alone have access to this API
    private ResponseEntity<Response> findBookingByBookingReferenceNo(@PathVariable String bookingReferenceNo) {
        return ResponseEntity.ok(bookingService.findBookingByBookingReferenceNo(bookingReferenceNo));
    }

    @PutMapping("/update")
    @PreAuthorize("hasAuthority('ADMIN')")  // ADMIN alone have access to this API
    private ResponseEntity<Response> updateBooking(@RequestBody BookingDto bookingDto) {
        return ResponseEntity.ok(bookingService.updateBooking(bookingDto));
    }



}
