package com.mwangotronix.HotelBooking.exceptions;

public class InvalidBookingStateAndaDateException extends RuntimeException {

    public InvalidBookingStateAndaDateException(String message) {
        super(message);
    }

}
