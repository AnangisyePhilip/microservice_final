package com.mwangotronix.HotelBooking.dtos;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.mwangotronix.HotelBooking.entities.User;
import com.mwangotronix.HotelBooking.enums.PaymentGateway;
import com.mwangotronix.HotelBooking.enums.PaymentStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentDto {
    private Long id;
    private String transactionId;
    private BigDecimal amount;
    private PaymentGateway paymentGateway;
    private LocalDateTime paymentDate;
    private PaymentStatus paymentStatus;
    private String bookingReference;
    private String failureReason;
    private String approvalLink;
}
