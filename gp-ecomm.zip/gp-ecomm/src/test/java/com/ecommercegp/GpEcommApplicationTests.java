package com.ecommercegp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpEcommApplicationTests {

	@Test
	void contextLoads() {
	}

}
