package com.ecommercegp.repository;

import com.ecommercegp.modal.OrderItem;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

    @Transactional
    @Modifying
    @Query("DELETE FROM OrderItem oim WHERE oim.order.id= :orderId")
    void deleteByOrderId(Long orderId);
}
