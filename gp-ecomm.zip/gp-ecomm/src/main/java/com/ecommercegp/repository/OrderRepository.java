package com.ecommercegp.repository;

import com.ecommercegp.modal.Order;
import com.ecommercegp.modal.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Long> {
    Optional<Order> getByOrderDateAndUserIdAndStatus(LocalDateTime orderDate, Long userId, OrderStatus status);

    Optional<Order> findByUuid(String uuid);
}
