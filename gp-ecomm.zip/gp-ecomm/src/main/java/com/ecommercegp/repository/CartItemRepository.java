package com.ecommercegp.repository;

import com.ecommercegp.modal.CartItem;
import com.ecommercegp.modal.Product;
import com.ecommercegp.modal.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CartItemRepository extends JpaRepository<CartItem,Long> {
    CartItem findByUserAndProduct(User user, Product product);

    void deleteByUserAndProduct(User user, Product product);

    List<CartItem> findByUser(User user);

    void deleteByUser(User user);
}
