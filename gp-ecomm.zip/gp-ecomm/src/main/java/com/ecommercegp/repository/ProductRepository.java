package com.ecommercegp.repository;

import com.ecommercegp.modal.Category;
import com.ecommercegp.modal.Product;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.awt.print.Pageable;

public interface ProductRepository extends JpaRepository<Product, Long> {
//    Page<Product> findByName(Category category, Pageable pageable);
//    Page<Product> findByNameContaining(String name, Pageable pageable);
@Modifying
@Transactional
@Query(value = "DELETE FROM products WHERE id = :id", nativeQuery = true)
void deleteProductById(Long id);
}

