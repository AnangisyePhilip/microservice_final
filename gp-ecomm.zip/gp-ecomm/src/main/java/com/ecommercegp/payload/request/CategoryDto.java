package com.ecommercegp.payload.request;

import lombok.Data;

@Data
public class CategoryDto {
    private String name;
    private String description;
}
