package com.ecommercegp.payload.request;


import com.ecommercegp.modal.OrderStatus;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;


@Data
public class OrderDto {
    private String uuid;
    private LocalDateTime orderDate;
    private BigDecimal totalPrice;
    private OrderStatus status;
    private Long userId;
    private List<OrderItemDto> items ;
}
