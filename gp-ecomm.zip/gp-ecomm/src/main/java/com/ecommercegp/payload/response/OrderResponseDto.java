package com.ecommercegp.payload.response;

import com.ecommercegp.modal.OrderItem;
import com.ecommercegp.modal.OrderStatus;
import com.ecommercegp.payload.request.OrderItemDto;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderResponseDto {
    private Long id;
    private LocalDateTime orderDate;
    private BigDecimal totalPrice;
    private OrderStatus status;
    private Long userId;

}
