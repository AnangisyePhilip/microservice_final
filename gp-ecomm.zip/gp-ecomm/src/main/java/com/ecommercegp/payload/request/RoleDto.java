package com.ecommercegp.payload.request;

import lombok.Data;

@Data
public class RoleDto {
    private Long id;
    private String name;
}
