package com.ecommercegp.service;

import com.ecommercegp.modal.CartItem;
import com.ecommercegp.payload.request.CartItemRequest;

import java.util.List;

public interface CartService {
    boolean addToCart(String userId, CartItemRequest request);

    boolean deleteItemFromCart(String userId, Long productId);

    List<CartItem> getCart(String userId);

    void clearCart(String userId);
}
