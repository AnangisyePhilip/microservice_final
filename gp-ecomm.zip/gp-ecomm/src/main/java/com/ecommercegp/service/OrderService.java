package com.ecommercegp.service;

import com.ecommercegp.modal.Order;
import com.ecommercegp.payload.request.OrderDto;
import com.ecommercegp.payload.response.OrderResponseDto;

import java.util.List;

public interface OrderService {
OrderResponseDto addOrder(OrderDto orderDto);
List<Order> getAllOrders();
OrderResponseDto getOrderById(Long id);
void deleteOrderById(Long id);
}
