package com.ecommercegp.service;

import com.ecommercegp.modal.Category;
import com.ecommercegp.payload.request.CategoryDto;
import com.ecommercegp.payload.response.CategoryResponseDto;

import java.util.List;

public interface CategoryService {
    CategoryResponseDto createCategory(CategoryDto categoryRequestDto);
    void deleteCategoryById(Long id);
    CategoryResponseDto getCategoryById(Long id);
     List<Category> getAllCategories();
}
