package com.ecommercegp.service;

import com.ecommercegp.modal.Product;
import com.ecommercegp.payload.request.ProductDto;

import java.util.List;

public interface ProductService {
    ProductDto createProduct(ProductDto productDto);
    ProductDto getProductById(Long id);
    List<Product> getAllProducts();
    void deleteProductById(Long id);
}
