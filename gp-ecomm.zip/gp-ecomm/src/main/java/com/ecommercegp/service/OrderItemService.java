package com.ecommercegp.service;

public interface OrderItemService {

}
