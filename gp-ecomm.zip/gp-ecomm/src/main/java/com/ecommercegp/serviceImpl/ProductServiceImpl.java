package com.ecommercegp.serviceImpl;

import com.ecommercegp.modal.Category;
import com.ecommercegp.modal.Product;
import com.ecommercegp.payload.request.ProductDto;
import com.ecommercegp.repository.CategoryRepository;
import com.ecommercegp.repository.ProductRepository;
import com.ecommercegp.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private ProductDto responseProductDto(Product product) {
        ProductDto productDto = new ProductDto();
        productDto.setId(product.getId());
        productDto.setName(product.getName());
        productDto.setCategoryId(product.getCategory().getId());
        productDto.setDescription(product.getDescription());
        productDto.setImageUrl(product.getImageUrl());
        productDto.setPrice(product.getPrice());
        return productDto;
    }


    @Override
    public ProductDto createProduct(ProductDto productDto) {
        // get the value from DTO
        String name = productDto.getName();
        String description = productDto.getDescription();
        String imageUrl = productDto.getImageUrl();
        BigDecimal price = productDto.getPrice();
        Long categoryId = productDto.getCategoryId();
        boolean isActive=productDto.getIsActive();

        logger.info("Creating Product");
        // Get the product category by categoryId
        Category retrievedCategory=categoryRepository.findById(categoryId).orElseThrow(()-> new RuntimeException("Category not found for ID:" + categoryId));

        Product product=new Product();
        product.setName(name);
        product.setDescription(description);
        product.setImageUrl(imageUrl);
        product.setPrice(price);
        product.setCategory(retrievedCategory);
        product.setIsActive(isActive);

        //Save product object

        Product savedProduct=productRepository.save(product);
        return responseProductDto(savedProduct);
    }
 
    @Override
    public ProductDto getProductById(Long id) {

        Product retrievedProduct=productRepository.findById(id).orElseThrow(()-> new RuntimeException("Product not found for ID:" + id));

        if(!Objects.isNull(retrievedProduct)){
            return responseProductDto(retrievedProduct);
        }
        return responseProductDto(retrievedProduct);
    }

    @Override
    public List<Product> getAllProducts() {

        List<Product> productList=productRepository.findAll();

        logger.info("getAllProducts");
        logger.info("Total products:{}", productList.size());
        return productList;
    }

    @Override
    public void deleteProductById(Long id) {

        Product product=productRepository.findById(id).orElseThrow(()-> new RuntimeException("Product not found for ID:" + id));

        productRepository.deleteProductById(id);
    }
}
