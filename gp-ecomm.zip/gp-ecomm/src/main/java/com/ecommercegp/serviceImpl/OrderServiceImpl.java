package com.ecommercegp.serviceImpl;

import com.ecommercegp.modal.*;
import com.ecommercegp.payload.request.OrderDto;
import com.ecommercegp.payload.response.OrderResponseDto;
import com.ecommercegp.repository.OrderItemRepository;
import com.ecommercegp.repository.OrderRepository;
import com.ecommercegp.repository.ProductRepository;
import com.ecommercegp.repository.UserRepository;
import com.ecommercegp.service.OrderService;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.logging.Logger;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final OrderItemRepository orderItemRepository;
    private final EntityManager entityManager;

    private final Logger logger = Logger.getLogger(OrderServiceImpl.class.getName());

    private static OrderResponseDto getOrderResponseDto(Order order) {
        OrderResponseDto orderResponseDto = new OrderResponseDto();
        orderResponseDto.setId(order.getId());
        orderResponseDto.setStatus(order.getStatus());
        orderResponseDto.setTotalPrice(order.getTotalPrice());
        orderResponseDto.setOrderDate(order.getOrderDate());
        orderResponseDto.setUserId(order.getUser().getId());
        return orderResponseDto;
    }

    @Transactional
    @Override
    public OrderResponseDto addOrder(OrderDto orderDto) {

        logger.info("create order");

        // Set
        String uuid=orderDto.getUuid();
        String status= String.valueOf(orderDto.getStatus());
        LocalDateTime orderDate=orderDto.getOrderDate();
        Long userId=orderDto.getUserId();


        // Check if DTO is valid

        logger.info("details sent:"+userId + orderDate + status );
        if(Objects.isNull(userId)  || Objects.isNull(orderDate) || Objects.isNull(status)){
            logger.severe("All fields are mandatory ");
            throw new RuntimeException("All fields are mandatory ");
        }

        // Check if exists
        if(Objects.isNull(uuid)){
            if (exist(orderDto)){
                logger.warning("Order already exist");
                throw new RuntimeException("Order already exist");
            }
        }

        // Find user by userId

        Optional<User> retrievedUser = userRepository.findById(userId);
        if (retrievedUser.isEmpty()){
            logger.warning("User not found");
            throw new RuntimeException("User not found");
        }

        User user=new User();
        user=retrievedUser.get();


        //Instantiate
        Order order;

        // Update | New
        if (Objects.nonNull(uuid)){
            order=orderDetails(uuid);

            //first delete all existing orderItems
            orderItemRepository.deleteByOrderId(order.getId());

            entityManager.flush();
            order.getOrderItems().clear();
        } else
        {
            order=new Order();
        }

        order.setOrderDate(orderDate);
        order.setUser(user);
        order.setStatus(OrderStatus.valueOf(status));

        //Add orderItems  to Order
        final BigDecimal[] totalPrice = {BigDecimal.ZERO};
        orderDto.getItems().forEach(orderItemDto ->{
            logger.info("Finding product with ID: " + orderItemDto.getProductId());
            Product product=productRepository.findById(orderItemDto.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found"));
        OrderItem orderItem=new OrderItem();
        orderItem.setQuantity(orderItemDto.getQuantity());
        orderItem.setProduct(product);
        orderItem.setPrice(product.getPrice().multiply(new BigDecimal(orderItemDto.getQuantity())));
        order.addOrderItem(orderItem);
        totalPrice[0] = totalPrice[0].add(orderItem.getPrice());
        });

        order.setTotalPrice(totalPrice[0]);
        Order savedOrder=orderRepository.save(order);

        return getOrderResponseDto(savedOrder);
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    public OrderResponseDto getOrderById(Long id) {
        Order order=orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        return getOrderResponseDto(order);
    }

    @Override
    public void deleteOrderById(Long id) {
        Order order=orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        orderRepository.deleteById(id);
    }

    private Boolean exist(OrderDto orderDto) {
        //Check if exist by orderDate ,status  and userId
        Optional<Order> order = orderRepository.getByOrderDateAndUserIdAndStatus(orderDto.getOrderDate(),orderDto.getUserId(),orderDto.getStatus());
        return order.isPresent();
    }

    private Order orderDetails(String uuid ) {
        Optional<Order> retrievedOrder = orderRepository.findByUuid(uuid);
        if(retrievedOrder.isEmpty()){
            logger.severe("Order  not found");
            throw new RuntimeException("Order not found");
        }
        return retrievedOrder.get();
    }
}
