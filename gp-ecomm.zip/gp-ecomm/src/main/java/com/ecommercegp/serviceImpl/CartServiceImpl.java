package com.ecommercegp.serviceImpl;


import com.ecommercegp.modal.CartItem;
import com.ecommercegp.modal.Product;
import com.ecommercegp.modal.User;
import com.ecommercegp.payload.request.CartItemRequest;
import com.ecommercegp.repository.CartItemRepository;
import com.ecommercegp.repository.ProductRepository;
import com.ecommercegp.repository.UserRepository;
import com.ecommercegp.service.CartService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class CartServiceImpl implements CartService {
    private final ProductRepository productRepository;
    private final CartItemRepository cartItemRepository;
    private final UserRepository userRepository;

    @Override
    public boolean addToCart(String userId, CartItemRequest request) {
        // Look for product
        log.info("adding user cart");
        Optional<Product> productOpt = productRepository.findById(request.getProductId());
        if (productOpt.isEmpty()){
            return false;
        }

        Product product = productOpt.get();
        if (product.getStockQuantity() < request.getQuantity()){
            return false;
        }
        Optional<User> userOpt=userRepository.findById(Long.valueOf(userId));
        if (userOpt.isEmpty()){
            return false;
        }
        User user = userOpt.get();
        CartItem existingCartItem=cartItemRepository.findByUserAndProduct(user,product);

        if (existingCartItem != null){
            // Update quantity
            existingCartItem.setQuantity(existingCartItem.getQuantity()+request.getQuantity());
            existingCartItem.setPrice(product.getPrice().multiply(BigDecimal.valueOf(existingCartItem.getQuantity())));
            cartItemRepository.save(existingCartItem);
        }
        else {
            //Create new cart item
            CartItem cartItem = new CartItem();
            cartItem.setUser(user);
            cartItem.setProduct(product);
            cartItem.setQuantity(request.getQuantity());
            cartItem.setPrice(product.getPrice().multiply(BigDecimal.valueOf(request.getQuantity())));
            cartItemRepository.save(cartItem);
        }
        return true;
    }

    @Override
    public boolean deleteItemFromCart(String userId, Long productId) {
        // Look for product
        log.info("adding user cart");
        Optional<Product> productOpt = productRepository.findById(productId);
        Optional<User> userOpt=userRepository.findById(Long.valueOf(userId));

        if (productOpt.isPresent() && userOpt.isPresent()){
            cartItemRepository.deleteByUserAndProduct(userOpt.get(),productOpt.get());
            return true;
        }

        return false;
    }

    @Override
    public List<CartItem> getCart(String userId) {
        return userRepository.findById(Long.valueOf(userId))
                .map(cartItemRepository::findByUser)
                .orElseGet(List::of);
    }

    @Override
    public void clearCart(String userId) {
        userRepository.findById(Long.valueOf(userId)).ifPresent(
                cartItemRepository::deleteByUser);
    }

}
