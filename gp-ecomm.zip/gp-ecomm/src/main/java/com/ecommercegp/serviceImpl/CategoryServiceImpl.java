package com.ecommercegp.serviceImpl;

import com.ecommercegp.modal.Category;
import com.ecommercegp.payload.request.CategoryDto;
import com.ecommercegp.payload.response.CategoryResponseDto;
import com.ecommercegp.repository.CategoryRepository;
import com.ecommercegp.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;

    private static CategoryResponseDto getCategoryResponseDto(Category category) {
        CategoryResponseDto responseDto = new CategoryResponseDto();
        responseDto.setName(category.getName());
        responseDto.setDescription(category.getDescription());
        return responseDto;
    }

    @Override
    public CategoryResponseDto createCategory(CategoryDto categoryRequestDto) {
    String name=categoryRequestDto.getName();
    String description=categoryRequestDto.getDescription();

    Category category=new Category();

    category.setName(name);
    category.setDescription(description);

    Category savedCategory=categoryRepository.save(category);
        return getCategoryResponseDto(savedCategory);
    }

    @Override
    public void deleteCategoryById(Long id) {
    Category category=categoryRepository.findById(id).orElseThrow(() -> new RuntimeException("Category not found"));
    categoryRepository.deleteById(id);
    }

    @Override
    public CategoryResponseDto getCategoryById(Long id) {
        Category category=categoryRepository.findById(id).orElseThrow(() -> new RuntimeException("Category not found"));
        return getCategoryResponseDto(category);
    }

    @Override
    public List<Category> getAllCategories() {

        return categoryRepository.findAll();
    }

}
