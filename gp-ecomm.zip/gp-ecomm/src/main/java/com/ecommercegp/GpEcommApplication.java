package com.ecommercegp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpEcommApplication {

	public static void main(String[] args) {
		SpringApplication.run(GpEcommApplication.class, args);
	}

}
