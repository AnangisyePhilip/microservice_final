package com.ecommercegp.modal;

public enum OrderStatus {

        PENDING,PROCESSING,SHIPPED,DELIVERED,CANCELLED
}
