package com.ecommercegp.controller;

import com.ecommercegp.modal.CartItem;
import com.ecommercegp.payload.request.CartItemRequest;
import com.ecommercegp.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;
    @PostMapping("/add")
    public ResponseEntity<String> addToCart(
            @RequestHeader("X-User-ID") String userId,
            @RequestBody CartItemRequest request
    ){

        if (!cartService.addToCart(userId,request)){
            return ResponseEntity.badRequest().body("Product Out of Stock or User not found Or Product not Found");
        }
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/items/{productId}")
    public ResponseEntity<Void> removeItemFromCart(
            @RequestHeader("X-User-ID") String userId,
            @PathVariable Long productId) {
        boolean deleted=cartService.deleteItemFromCart(userId,productId);

        return ResponseEntity.noContent().build();
    }

    @GetMapping("/all")
    public  ResponseEntity<List<CartItem>> getCart(
            @RequestHeader("X-User-ID") String userId){
        return ResponseEntity.ok(cartService.getCart(userId));
    }
}
