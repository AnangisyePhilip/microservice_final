package com.ecommercegp.controller;

import com.ecommercegp.modal.Product;
import com.ecommercegp.payload.request.ProductDto;
import com.ecommercegp.payload.response.ProductResponseDto;
import com.ecommercegp.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    @PostMapping("/add")
    public ProductDto addProduct( @RequestBody ProductDto productDto) {
        return productService.createProduct(productDto);
    }

    @GetMapping("/all")
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/{id}")
    public ProductDto getProduct(@PathVariable Long id) {
        return productService.getProductById(id);
    }


    @DeleteMapping("/delete/{id}")
    public void deleteProduct(@PathVariable Long id) {
        productService.deleteProductById(id);
    }
}
