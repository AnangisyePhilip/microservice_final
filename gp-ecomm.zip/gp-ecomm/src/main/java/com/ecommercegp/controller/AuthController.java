package com.ecommercegp.controller;

import com.ecommercegp.payload.request.LoginRequest;
import com.ecommercegp.payload.request.RegisterRequest;
import com.ecommercegp.payload.request.auth.AuthResponse;
import com.ecommercegp.service.AuthenticationService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Getter
@Setter
public class AuthController {
    private final AuthenticationService authService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(
            @Valid @RequestBody RegisterRequest request
    ) {
        return ResponseEntity.ok(authService.register(request));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(
            @Valid @RequestBody LoginRequest request
    ) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        boolean logoutSuccessful = authService.logout(request);

        if (logoutSuccessful) {
            return ResponseEntity.ok()
                    .body(new ApiResponse(true, "Logged out successfully"));
        } else {
            return ResponseEntity.badRequest()
                    .body(new ApiResponse(false, "Logout failed"));
        }
    }

    // Simple response class for logout response
    @Getter
    private static class ApiResponse {
        private final boolean success;
        private final String message;

        public ApiResponse(boolean success, String message) {
            this.success = success;
            this.message = message;
        }

    }
}
